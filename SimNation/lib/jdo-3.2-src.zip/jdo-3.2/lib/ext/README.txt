This directory is added to the classpath when running the JDO TCK.
It contains libraries that are not distributed as part of JDO.

